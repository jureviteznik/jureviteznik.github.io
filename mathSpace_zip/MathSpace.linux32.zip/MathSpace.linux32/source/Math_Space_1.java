import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Math_Space_1 extends PApplet {



enum Screen{
    MENU, GAME, GAMEOVER, GAMEPAUSE
};

Screen onScreen;

String skinMap;
String[] skins = {"scarab", "doodle","buzz","school","pokemon"};
String[] modes = {"Marathon", "Sprint", "Turnado", "Twirl"};
String[] modeDescription = {
    //marathon 
    "After 10 slutions you level up and equations spawn faster!",
    //Sprint
    "Each slutions speeds the game up!",
    //Turnado
    "Spinning gets faster and faster!",
    //Twirl
    "Fisrt only 1 equation will apear, then 2, then 3,.. and so on!"
  };

Game gameMode;
int selectedRectX;
int selectedRectY;
int selectedModeX;

SoundFile backgroundMusic;
SoundFile wrongSound;
SoundFile correctSound;
SoundFile shipHitSound;
float musicVolume;
HScrollbar volumeSlider;


PImage[] spaceships = new PImage[3];
PImage spaceShip;
PImage inputNum1;
PImage inputNum2;
PImage background;
PImage meteor;
PImage stevilcnica;
PImage select;
PImage wrong;
PImage[] bulletANI_ = new PImage[0];
ArrayList<PImage> bulletANI;

PImage nic;
PImage ena;
PImage dva;
PImage tri;
PImage stiri;
PImage pet;
PImage sest;
PImage sedem;
PImage osem;
PImage devet;

float shipAngle;

IntList mozneStevke;

ArrayList<Meteor> meteors;
Meteor selected;

ArrayList<Bullet> bullets;

int result;

int lives;
int numOfDestroied;
int numOfMissed;

float distX;
float distY;
int meteorRadius;
float mouseDistance;

int initialTime;


public void setup(){
  
  frameRate(30);
  background(0);
  
  onScreen = Screen.MENU;
  
  background = loadImage("Pics/background.png");
  
  skinMap = "Pics/scarab";
  gameMode = new Marathon();
  selectedRectX = 0;
  selectedRectY = height/3;
  selectedModeX = 0;
  
  changeSkin();
  
  backgroundMusic = new SoundFile(this, "Sounds/background1.wav");
  backgroundMusic.loop();
  musicVolume = 0.7f;
  volumeSlider = new HScrollbar(width/2, height - height/20, width/2, height/20, 1); 
  backgroundMusic.amp(musicVolume);
  
  wrongSound = new SoundFile(this, "Sounds/wrong1.mp3");
  correctSound = new SoundFile(this, "Sounds/correct1.wav");
  shipHitSound = new SoundFile(this, "Sounds/shipHit1.wav");
  

  
  meteors = new ArrayList<Meteor>();
  bullets = new ArrayList<Bullet>();
  mozneStevke = new IntList();
  mozneStevke.append(1);
  mozneStevke.append(2);
  mozneStevke.append(3);
  mozneStevke.append(4);
  mozneStevke.append(5);
  mozneStevke.append(6);
  mozneStevke.append(7);
  mozneStevke.append(8);
  mozneStevke.append(9);
  
  lives = 0;
  numOfDestroied = 0;
  numOfMissed = 0;
  
  result = 0;
  meteorRadius = meteor.height/2;
  
  initialTime = millis();
}

public void draw(){
  switch(onScreen){
    case MENU:{
      drawMenu();
      break;
    }
    case GAME:{
      gameMode.drawGame();
      break;
    }
    case GAMEOVER:{
      drawGameover();
      break;
    }
    case GAMEPAUSE:{
      drawGamepause();
      break;
    }
  }
}

public void mousePressed(){
  switch(onScreen){
    case MENU:{
      mouseMenu();
      break;
    }
    case GAME:{
      mouseGame();
      break;
    }
    case GAMEOVER:{
      resetGame();
      break;
    }
    case GAMEPAUSE:{
      onScreen = Screen.GAME;
      break;
    }
  }
 
}

public void keyPressed(){
  switch(onScreen){
    case MENU:{
      break;
    }
    case GAME:{
      if(key == ESC){
        key = 0;
        onScreen = Screen.GAMEPAUSE;
      }
      
      break;
    }
    case GAMEOVER:{
      break;
    }
    case GAMEPAUSE:{
      if(key == ESC){
        key = 0;
        resetGame();
      }
      break;
    }
  }
}

public void drawGameover(){
    background(background);
    textSize(width/10);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width/2 ,height/2);
    
    textSize(width/20);
    text("Correct: " + numOfDestroied, width/2 ,height - height/3);
    text("Wrong: " + numOfMissed, width/2 ,height - height/4);
    //TODO ADD CLICK TO MENU
    
  };

public void drawGamepause(){
    background(background);
    textSize(width/10);
    textAlign(CENTER, CENTER);
    text("PAUSE", width/2 ,height/2);
    
    textSize(width/20);
    text("Mouse click to resume", width/2 ,height - height/3);
    text("Press ESC to exit to menu", width/2 ,height - height/4);
}

public void drawMenu(){
  background(background);
  
  //VOLUME
  textAlign(LEFT, BOTTOM);
  text("Volume:", width/2 + 5, height-height/14);
  volumeSlider.update();
  volumeSlider.display();
  backgroundMusic.amp(volumeSlider.getVol());
  wrongSound.amp(volumeSlider.getVol());
  correctSound.amp(volumeSlider.getVol());
  shipHitSound.amp(volumeSlider.getVol());
  textAlign(CENTER, CENTER);
  
  shipAngle = atan2(mouseY-3*height/4, mouseX-3*width/4);
  
  //draw spaceship
  pushMatrix();
    translate(3*width/4, 3*height/4);
    rotate(shipAngle + PI/2);
    imageMode(CENTER);
    image(spaceShip, 0, 0);
  popMatrix();
  
  //draw meteor and nuber selector
  pushMatrix();
    translate(3*width/4, height/4);
    imageMode(CENTER);
    image(stevilcnica, 0, 0);
    image(meteor, 0, 0, 100, 100);
  popMatrix();
    float angle;
    
    if(mozneStevke.hasValue(3)){
         //3
         pushMatrix();
        translate(3*width/4, height/4);
        angle = PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(4)){
       //4
       pushMatrix();
    translate(3*width/4, height/4);
       angle = 3*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(5)){
       //5
       pushMatrix();
    translate(3*width/4, height/4);
       angle = 5*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(6)){
       //6
       pushMatrix();
    translate(3*width/4, height/4);
       angle = 7*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(7)){
       //7
       pushMatrix();
    translate(3*width/4, height/4);
       angle = 9*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(8)){
       //8
       pushMatrix();
    translate(3*width/4, height/4);
       angle = -9*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(9)){
       //9
       pushMatrix();
    translate(3*width/4, height/4);
       angle = -7*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(1)){
       //1
       pushMatrix();
    translate(3*width/4, height/4);
       angle = -3*PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }
    if(mozneStevke.hasValue(2)){
       //2
       pushMatrix();
        translate(3*width/4, height/4);
       angle = -PI/10;
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
        popMatrix();
     }


  //draw lines
  stroke(255);
  strokeWeight(5);
  line(width/2, 0, width/2, height);
  line(0, height/3, width/2, height/3);
  line(0, 2*height/3, width/2, 2*height/3);
  
  strokeWeight(3);
  line(0, height/2, width/2, height/2);
  line(0, 5*height/6, width/2, 5*height/6);
  line(width/10, height/3, width/10, 5*height/6);
  line(2*width/10, height/3, 2*width/10, 5*height/6);
  line(3*width/10, height/3, 3*width/10, 5*height/6);
  line(4*width/10, height/3, 4*width/10, 5*height/6);
  
  
  //draw skin stuff
  noFill();
  stroke(204, 102, 0);
  strokeWeight(5);
  rect(selectedRectX, selectedRectY, width/10, height/6);
  
  textSize(32);
  textAlign(CENTER);
  
  //skin selection
  fill(255, 204, 0);
  int index = 0;
  for(int j = height/3; j < 2*height/3; j += height/6){
    for(int i = 0;  i < width/2; i += width/10){
      try{
        text(skins[index], i + width/20, j + height/12);
      }catch(Exception e){}
      index++;
    }
    
  }
  //mode selection
  fill(0, 255, 0);
  index = 0;
  for(int i = 0;  i < width/2; i += width/10){
    try{
      text(modes[index], i + width/20, 2*height/3 + height/12);
    }catch(Exception e){}
    index++;
  }
  
  //game selection/game modes
  noFill();
  stroke(204, 255, 0);
  strokeWeight(5);
  rect(selectedModeX, 4*height/6, width/10, height/6);
  
  index = 0;
  if(gameMode instanceof Marathon){
      index = 0;
  }else if(gameMode instanceof Sprint){
    index = 1;
  }else if(gameMode instanceof Turnado){
    index = 2;
  }else if(gameMode instanceof Twirl){
    index = 3;
  }
  fill(255,0, 0);
  text(modeDescription[index], 0, 21*height/24, width/2, height);
  /*
  for(int i = 0;  i < width/2; i += width/10){
    try{
      text(modes[index], i + width/20, 5*height/6 + height/12);
    }catch(Exception e){}
    index++;
  }
  */
  
  //play button
  fill(255,255,255);
  text("PLAY", width/4,height/6);
  
  
}



public void mouseMenu(){
  
  //skin selection
  if(mouseX < width/2 && mouseY < 2*height/3 && mouseY > height/3){
    int sel = 0;
    
    if(mouseX < width/10){
      selectedRectX = 0;
      sel = 0;
    }else if(mouseX < 2*width/10){
      selectedRectX = width/10;
      sel = 1;
    }else if(mouseX < 3*width/10){
      selectedRectX = 2*width/10;
      sel = 2;
    }else if(mouseX < 4*width/10){
      selectedRectX = 3*width/10;
      sel = 3;
    }else if(mouseX < 5*width/10){
      selectedRectX = 4*width/10;
      sel = 4;
    }
    
    if(mouseY < height/2)  selectedRectY = height/3;
    else{
      selectedRectY = height/2;
      sel += 5;
    }
    
    try{
      skinMap = "Pics/" + skins[sel];
    }catch(Exception e){
       //skinMap = "Pics/casino";
    }
    
    changeSkin();
    
  }
  
  //extra selection
  else if(mouseX < width/2 && mouseY <   height
                           && mouseY > 2*height/3){
   
   //game mode selection
    if(mouseY < 5*height/6){
      if(mouseX < width/10){
        //MARATHON
        selectedModeX = 0;
        gameMode = new Marathon();
        
      }else if(mouseX < 2*width/10){
        //SPRINT
        selectedModeX = width/10;
        gameMode = new Sprint();
        
      }else if(mouseX < 3*width/10){
        selectedModeX = 2*width/10;
        gameMode = new Turnado();
        
      }else if(mouseX < 4*width/10){
        selectedModeX = 3*width/10;
        gameMode = new Twirl();
      }else if(mouseX < 5*width/10){
        //selectedModeX = 4*width/10;
       
      }
    }else{
      
    }
    
    
  }
  
  if(mouseX < width/2 && mouseY < height/3){
    onScreen = Screen.GAME;
    if(mozneStevke.size() == 0){
      mozneStevke.append(1);
      mozneStevke.append(2);
      mozneStevke.append(3);
      mozneStevke.append(4);
      mozneStevke.append(5);
      mozneStevke.append(6);
      mozneStevke.append(7);
      mozneStevke.append(8);
      mozneStevke.append(9);
    }
  }
  
  //number selection
  mouseDistance = dist(mouseX, mouseY, 3*width/4, height/4);
  if(mouseDistance <= stevilcnica.width/2){ 
         float angle = atan2(mouseY-height/4, mouseX-3*width/4);
         
         if(angle > 0 && angle < PI/5){
           //3
           if(mozneStevke.hasValue(3)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 3){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(3);
           }
         }else if(angle > PI/5 && angle < 2*PI/5){
           //4
           if(mozneStevke.hasValue(4)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 4){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(4);
           }
         }else if(angle > 2*PI/5 && angle < 3*PI/5){
           //5
           if(mozneStevke.hasValue(5)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 5){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(5);
           }
         }else if(angle > 3*PI/5 && angle < 4*PI/5){
           //6
           if(mozneStevke.hasValue(6)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 6){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(6);
           }
         }else if(angle > 4*PI/5 && angle < 5*PI/5){
           //7
           if(mozneStevke.hasValue(7)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 7){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(7);
           }
         }else if(angle > -5*PI/5 && angle < -4*PI/5){
           //8
           if(mozneStevke.hasValue(8)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 8){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(8);
           }
         }else if(angle > -4*PI/5 && angle < -3*PI/5){
           //9
           if(mozneStevke.hasValue(9)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 9){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(9);
           }
         }else if(angle > -2*PI/5 && angle < -PI/5){
           //1
            if(mozneStevke.hasValue(1)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 1){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(1);
           }
         }else if(angle > -PI/5 && angle < 0){
           //2
           if(mozneStevke.hasValue(2)){
             for(int i = 0; i < mozneStevke.size(); i++){
               if(mozneStevke.get(i) == 2){
                 mozneStevke.remove(i);
               }
             }
           }else{
             mozneStevke.append(2);
           }
         }
  }
  
}

public void mouseGame(){
  if(selected != null){
    mouseDistance = dist(mouseX, mouseY, selected.posx, selected.posy);
    
    if(mouseDistance <= stevilcnica.width/2){   
         float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
         
         if(angle > 0 && angle < PI/5){
           //3
           result = result*10 + 3;
           if(inputNum1 == null) inputNum1 = tri;
           else inputNum2 = tri;
         }else if(angle > PI/5 && angle < 2*PI/5){
           //4
           result = result*10 + 4;
           if(inputNum1 == null) inputNum1 = stiri;
           else inputNum2 = stiri;
         }else if(angle > 2*PI/5 && angle < 3*PI/5){
           //5
           result = result*10 + 5;
           if(inputNum1 == null) inputNum1 = pet;
           else inputNum2 = pet;
         }else if(angle > 3*PI/5 && angle < 4*PI/5){
           //6
           result = result*10 + 6;
           if(inputNum1 == null) inputNum1 = sest;
           else inputNum2 = sest;
         }else if(angle > 4*PI/5 && angle < 5*PI/5){
           //7
           result = result*10 + 7;
           if(inputNum1 == null) inputNum1 = sedem;
           else inputNum2 = sedem;
         }else if(angle > -5*PI/5 && angle < -4*PI/5){
           //8
           result = result*10 + 8;
           if(inputNum1 == null) inputNum1 = osem;
           else inputNum2 = osem;
         }else if(angle > -4*PI/5 && angle < -3*PI/5){
           //9
           result = result*10 + 9;
           if(inputNum1 == null) inputNum1 = devet;
           else inputNum2 = devet;
         }else if(angle > -3*PI/5 && angle < -2*PI/5){
           //0
           result = result*10 + 0;
           if(inputNum1 == null) inputNum1 = nic;
           else inputNum2 = nic;
         }else if(angle > -2*PI/5 && angle < -PI/5){
           //1
           result = result*10 + 1;
           if(inputNum1 == null) inputNum1 = ena;
           else inputNum2 = ena;
         }else if(angle > -PI/5 && angle < 0){
           //2
           result = result*10 + 2;
           if(inputNum1 == null) inputNum1 = dva;
           else inputNum2 = dva;
         }
         
         int result2 = result % 10;
         
         //CHECK IF THE RESULT IS CORRECT
         if(selected.rezultat == result || selected.rezultat == result2){
           correctSound.play();
           
           Bullet b = new Bullet(selected, inputNum1, inputNum2);
           bullets.add(b);
           
           //meteors.remove(selected);
           selected = null;
           result = 0;
           inputNum1 = null;
           inputNum2 = null;
           
         }else if(result > 10){
           //we entered 2 number is the result is 10 or bigger, if we didnt get it we reset the result value to 0 cuz we missed it
           //wrongSound.play();
           result = 0;
           inputNum1 = null;
           inputNum2 = null;
           numOfMissed++;
           selected.wrongTime = millis();
         }  
         
         return;
       }else{
         selected = null;
         result = 0;
         inputNum1 = null;
         inputNum2 = null;
       }
  }else{
    for(int i = 0; i < meteors.size(); i++){
       Meteor m = meteors.get(i);
       mouseDistance = dist(mouseX, mouseY, m.posx, m.posy);
       if(mouseDistance <= meteorRadius/2){
          selected = m;
       }
    }
  }
}

public void resetGame(){
  numOfDestroied = 0;
  numOfMissed = 0;
  meteors = new ArrayList<Meteor>();
  lives = 0;
  spaceShip = spaceships[0];
  onScreen = Screen.MENU;
  if(gameMode instanceof Marathon){
    gameMode = new Marathon();
  }else if(gameMode instanceof Sprint){
    gameMode = new Sprint();
  }else if(gameMode instanceof Turnado){
    gameMode = new Turnado();
  }else if(gameMode instanceof Twirl){
    gameMode = new Twirl();
  }
}

public void changeSkin(){
  spaceships[0] = loadImage(skinMap+"/space_ship1.png");
  spaceships[1] = loadImage(skinMap+"/space_ship2.png");
  spaceships[2] = loadImage(skinMap+"/space_ship3.png");
  spaceShip = spaceships[0];
  meteor = loadImage(skinMap+"/meteor.png");
  stevilcnica = loadImage(skinMap+"/select_circle.png");
  select = loadImage(skinMap+"/select.png");
  wrong = loadImage(skinMap+"/wrong.png");
  
  nic = loadImage(skinMap+"/0.png");
  ena = loadImage(skinMap+"/1.png");
  dva = loadImage(skinMap+"/2.png");
  tri = loadImage(skinMap+"/3.png");
  stiri = loadImage(skinMap+"/4.png");
  pet = loadImage(skinMap+"/5.png");
  sest = loadImage(skinMap+"/6.png");
  sedem = loadImage(skinMap+"/7.png");
  osem = loadImage(skinMap+"/8.png");
  devet = loadImage(skinMap+"/9.png");
  
}

/*
code from https://processing.org/examples/scrollbar.html
used for a volume slider 
*/
class HScrollbar {
  int swidth, sheight;    // width and height of bar
  float xpos, ypos;       // x and y position of bar
  float spos, newspos;    // x position of slider
  float sposMin, sposMax; // max and min values of slider
  int loose;              // how loose/heavy
  boolean over;           // is the mouse over the slider?
  boolean locked;
  float ratio;

  HScrollbar (float xp, float yp, int sw, int sh, int l) {
    swidth = sw;
    sheight = sh;
    int widthtoheight = sw - sh;
    ratio = (float)sw / (float)widthtoheight;
    xpos = xp;
    ypos = yp-sheight/2;
    spos = xpos + swidth/2 - sheight/2;
    newspos = spos;
    sposMin = xpos;
    sposMax = xpos + swidth - sheight;
    loose = l;
  }

  public void update() {
    if (overEvent()) {
      over = true;
    } else {
      over = false;
    }
    if (mousePressed && over) {
      locked = true;
    }
    if (!mousePressed) {
      locked = false;
    }
    if (locked) {
      newspos = constrain(mouseX-sheight/2, sposMin, sposMax);
    }
    if (abs(newspos - spos) > 1) {
      spos = spos + (newspos-spos)/loose;
    }
  }

  public float constrain(float val, float minv, float maxv) {
    return min(max(val, minv), maxv);
  }

  public boolean overEvent() {
    if (mouseX > xpos && mouseX < xpos+swidth &&
       mouseY > ypos && mouseY < ypos+sheight) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    noStroke();
    fill(204);
    rect(xpos, ypos, swidth, sheight);
    if (over || locked) {
      fill(0, 0, 0);
    } else {
      fill(102, 102, 102);
    }
    rect(spos, ypos, sheight, sheight);
  }

  public float getPos() {
    // Convert spos to be values between
    // 0 and the total width of the scrollbar
    return spos * ratio;
  }
  
  public float getVol(){
    return (spos / swidth) - 1;
  }
}
class Bullet{
  float posx;
  float posy;
  
  float angle;
  
  float speed = 25;
  
  Meteor goal;
  
  int animationTics = 0;
  int animationDelay = 0;
  
  PImage bullet;
  
  PImage num1;
  PImage num2;
  
  //update and draw
  public void update(){
    
    angle = atan2(goal.posy-posy, goal.posx-posx);
    
    /*
    if(animationDelay > 0){
      animationDelay--;
    }else{
      animationDelay = 3;
      int index = animationTics % bulletANI.size();
      bullet = bulletANI.get(index);
      animationTics++;
    }
    */
    
    
    pushMatrix();
      translate(posx,posy);
      imageMode(CENTER);
      rotate(angle + PI/2);
      
      translate(-16, 0);
      image(num1, 0, 0, 30, 30);
      if(num2 != null){
        translate(32,0);
        image(num2, 0, 0, 30, 30);
      }
      
      
      //image(bullet, 0, 0);
    popMatrix();
    
    posx += cos(angle) * speed;
    posy += sin(angle) * speed;
    
    
    //when bullet hits delete the meteor and bullet
    distX = posx - goal.posx;
    distY = posy - goal.posy;
    mouseDistance = sqrt((distX*distX) + (distY*distY));
     
    if(mouseDistance <= meteorRadius){ 
      meteors.remove(goal);
      bullets.remove(this);
      numOfDestroied++;
    }
      
    animationTics++;
  
  }
  
  Bullet(Meteor m, PImage n1, PImage n2){
    posx = width/2;
    posy = height/2;
    
    num1 = n1;
    num2 = n2;
    
    goal = m;
    
  }
}
interface Game{
  public void drawGame();
}

/*
//////////
/TEMPLATE/
//////////

void drawGame(){
  background(0);
  fill(255);
  
  //spawn new meteors
  if(millis() - initialTime > interval){
    meteors.add(new Meteor(mozneStevke));
    initialTime = millis();
  }

  //draw input circle
  if(selected != null){
    float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
    pushMatrix();
      translate(selected.posx, selected.posy);
      imageMode(CENTER);
      image(stevilcnica, 0, 0);
      
      if(angle > 0 && angle < PI/5){
           //3
           angle = PI/10;
         }else if(angle > PI/5 && angle < 2*PI/5){
           //4
           angle = 3*PI/10;
         }else if(angle > 2*PI/5 && angle < 3*PI/5){
           //5
           angle = 5*PI/10;
         }else if(angle > 3*PI/5 && angle < 4*PI/5){
           //6
           angle = 7*PI/10;
         }else if(angle > 4*PI/5 && angle < 5*PI/5){
           //7
           angle = 9*PI/10;
         }else if(angle > -5*PI/5 && angle < -4*PI/5){
           //8
           angle = -9*PI/10;
         }else if(angle > -4*PI/5 && angle < -3*PI/5){
           //9
           angle = -7*PI/10;
         }else if(angle > -3*PI/5 && angle < -2*PI/5){
           //0
           angle = -5*PI/10;
         }else if(angle > -2*PI/5 && angle < -PI/5){
           //1
           angle = -3*PI/10;
         }else if(angle > -PI/5 && angle < 0){
           //2
           angle = -PI/10;
         }
         
      rotate(angle + PI/2);
      translate(0,-100);
      image(select,0,0);
    popMatrix();
    
    shipAngle = atan2(selected.posy-height/2, selected.posx-width/2);
  }else{
    shipAngle = atan2(mouseY-height/2, mouseX-width/2);
  }
  
  //draw spaceship
  
  pushMatrix();
    translate(width/2, height/2);
    rotate(shipAngle + PI/2);
    imageMode(CENTER);
    image(spaceShip, 0, 0);
  popMatrix();
  
  //update/draw meteors
  for(int i = 0; i < meteors.size(); i++){
    Meteor m = meteors.get(i);
    m.update();
    if(m.hitShip()){
      lives++;
      //GAME OVER
       if(lives >= spaceships.length){
         onScreen = Screen.GAMEOVER;
       }else{
         spaceShip = spaceships[lives];
       }
      if(m == selected){
        selected = null;      
      }
      meteors.remove(i);
    }
  }
  
  //update/draw bullets
  for(int i = 0; i < bullets.size(); i++){
    Bullet b = bullets.get(i);
    b.update();
  }
}

*/
class Marathon implements Game{
  int prevNumOfDestroied;
  int speed;
  int speedDecrese;
  int level;
  //check meteor constructor for detail
  float aMax, aMin, rMax, rMin;
  
  public Marathon(){
    prevNumOfDestroied = 0;
    speed = 10000; //start with 10 seconds
    speedDecrese = 1000; // on level up decrese by 1 sec, 1 sec respawn time at level 10
    level = 1;
    aMax = 0.008f;
    aMin = 0.002f;
    rMax = 0.5f;
    rMin = 0.7f;
  }
  

 
  public void drawGame(){
    background(background);
    fill(255);
    
    //spawn new meteors
    if(millis() - initialTime > speed){
      meteors.add(new Meteor(mozneStevke, aMin, aMax, rMin, rMax));
      initialTime = millis();
    }
    //check if we need to go to the next level
    if(prevNumOfDestroied != numOfDestroied){
      prevNumOfDestroied = numOfDestroied;
      if(numOfDestroied % 10 == 0 && level < 10){
        speed -= speedDecrese;
        level++;
      }
    }
    //draw level and how many left to level up
    textSize(32);
    textAlign(LEFT, TOP);
    if(level < 10){
      text("Level: " + level, 0, 0);
      text("Next Level: " + (10 - numOfDestroied % 10), 0, 35);
    }  
    else{
      text("Level: 10(max)", 0, 0);
      text("Next Level: inf.", 0, 35);
    }            
    
    //draw spaceship
    
    pushMatrix();
      translate(width/2, height/2);
      rotate(shipAngle + PI/2);
      imageMode(CENTER);
      image(spaceShip, 0, 0);
       
      if(inputNum1 != null){
          translate(0,-spaceShip.height/2);
          image(inputNum1, 0, -15, 30, 30);
      }
      
      
    popMatrix();
    
    //update/draw meteors
    for(int i = 0; i < meteors.size(); i++){
      Meteor m = meteors.get(i);
      if(m != selected) m.update();
      
      if(m.hitShip()){
        lives++;
        //GAME OVER
         if(lives >= spaceships.length){
           onScreen = Screen.GAMEOVER;
         }else{
           spaceShip = spaceships[lives];
         }
        if(m == selected){
          selected = null;      
        }
        meteors.remove(i);
      }
    }
    
    
    //draw input circle
    if(selected != null){
      float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
      pushMatrix();
        translate(selected.posx, selected.posy);
        imageMode(CENTER);
        image(stevilcnica, 0, 0);
        
        if(angle > 0 && angle < PI/5){
             //3
             angle = PI/10;
           }else if(angle > PI/5 && angle < 2*PI/5){
             //4
             angle = 3*PI/10;
           }else if(angle > 2*PI/5 && angle < 3*PI/5){
             //5
             angle = 5*PI/10;
           }else if(angle > 3*PI/5 && angle < 4*PI/5){
             //6
             angle = 7*PI/10;
           }else if(angle > 4*PI/5 && angle < 5*PI/5){
             //7
             angle = 9*PI/10;
           }else if(angle > -5*PI/5 && angle < -4*PI/5){
             //8
             angle = -9*PI/10;
           }else if(angle > -4*PI/5 && angle < -3*PI/5){
             //9
             angle = -7*PI/10;
           }else if(angle > -3*PI/5 && angle < -2*PI/5){
             //0
             angle = -5*PI/10;
           }else if(angle > -2*PI/5 && angle < -PI/5){
             //1
             angle = -3*PI/10;
           }else if(angle > -PI/5 && angle < 0){
             //2
             angle = -PI/10;
           }
           
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
      popMatrix();
      
      shipAngle = atan2(selected.posy-height/2, selected.posx-width/2);
    }else{
      shipAngle = atan2(mouseY-height/2, mouseX-width/2);
    }
    if(selected != null)  selected.update();
    
    
    //update/draw bullets
    for(int i = 0; i < bullets.size(); i++){
      Bullet b = bullets.get(i);
      b.update();
    }
  }
}
class Meteor{
  float radius;
  float posx;
  float posy;
  float angle;
  
  //time for X after the wrong answer
  float wrongTime;
  
  //change of angle
  float da;
  //change of radius
  float dr;
  
  PImage st1;
  PImage st2;
  int rezultat;
 
  //no idea se kku
  int speed;
  
  //draw and update meteor
  public void update(){
    //draw meteor base
    pushMatrix();
      translate(posx,posy);
      imageMode(CENTER);
      image(meteor, 0, 0,100,100);

    popMatrix();
    
    //draw numbers inside the meteor
    pushMatrix();
      translate(posx - 16, posy);
      imageMode(CENTER);
      image(st1, 0, 0, 30, 30);
      translate(32,0);
      image(st2, 0, 0, 30, 30);
      translate(-16,0);
      image(wrong,0,0,15,15);
      
    popMatrix();
    
    if(millis() - wrongTime < 500){
      pushMatrix();
       translate(posx,posy);
       imageMode(CENTER);
       image(wrong, 0, 0);
      popMatrix();
    }
    
    //update
    posx = radius * cos(angle) + width/2;
    posy = radius * sin(angle) + height/2;
    angle += da;
    radius -= dr;
    
  }
  
  public boolean hitShip(){
    if(radius < spaceShip.height){
      shipHitSound.play();
      return true;
    }
    return false;
  }
  
  // nubers[] is array of numbers we can select
  // aMin aMax - min and max number for change of angle
  // rMin rMax - min and max number for change of radius
  Meteor(IntList numbers, float aMin, float aMax, float rMin, float rMax){
    
    wrongTime = 0;
    
    //meteor spawns at the top in the middle, just above the screen
    //posx = width/2;
    //posy = -meteor.height/2;
   
    int fromWhere = (int)random(2);
    switch(fromWhere){
      case 1:{
        radius = height/2 + 100;
        angle = PI/2;
        break;
      }
      case 0:{
        radius = height/2 + 100;
        angle = -PI/2;
        break;
      }
    }
    
    da = random(aMin, aMax);
    dr = random(rMin, rMax);
    
    posx = radius * cos(angle) + width/2;
    posy = radius * sin(angle) + height/2;
    
    
    int index = (int)random(numbers.size());
    rezultat = numbers.get(index);
     switch(numbers.get(index)){
       case 1:{
         st1 = ena;
         break;
       }
       case 2:{
         st1 = dva;
         break;
       }
       case 3:{
         st1 = tri;
         break;
       }
       case 4:{
         st1 = stiri;
         break;
       }
       case 5:{
         st1 = pet;
         break;
       }
       case 6:{
         st1 = sest;
         break;
       }
       case 7:{
         st1 = sedem;
         break;
       }
       case 8:{
         st1 = osem;
         break;
       }
       case 9:{
         st1 = devet;
         break;
       }
     }
     
     index = (int)random(1,10);
     rezultat *= index;
     
     switch(index){
       case 1:{
         st2 = ena;
         break;
       }
       case 2:{
         st2 = dva;
         break;
       }
       case 3:{
         st2 = tri;
         break;
       }
       case 4:{
         st2 = stiri;
         break;
       }
       case 5:{
         st2 = pet;
         break;
       }
       case 6:{
         st2 = sest;
         break;
       }
       case 7:{
         st2 = sedem;
         break;
       }
       case 8:{
         st2 = osem;
         break;
       }
       case 9:{
         st2 = devet;
         break;
       }
       
     }
  }
}
class Sprint implements Game{
  int prevNumOfDestroied;
  //check meteor constructor for detail
  float aMax, aMin, rMax, rMin;
  
  //meteor speed increse when you destroy one
  float da, dr; 
  
  public Sprint(){
    aMax = 0.008f;
    aMin = 0.002f;
    rMax = 0.5f;
    rMin = 0.7f;
    
    da = 0.0001f;
    dr = 0.05f;
  }
  
 
 
  public void drawGame(){
    background(background);
    fill(255);
    
    //spawn new meteors
    if(meteors.isEmpty()){
      aMax += da;
      aMin += da;
      rMax += dr;
      rMax += dr;
      meteors.add(new Meteor(mozneStevke, aMin, aMax, rMin, rMax));
    }
   
    //draw number of destroied meteors
    textSize(32);
    textAlign(LEFT, TOP);
    
    text("Score: " + numOfDestroied, 0, 0);
              
    
    //draw spaceship
    
    pushMatrix();
      translate(width/2, height/2);
      rotate(shipAngle + PI/2);
      imageMode(CENTER);
      image(spaceShip, 0, 0);
       
      if(inputNum1 != null){
          translate(0,-spaceShip.height/2);
          image(inputNum1, 0, -15, 30, 30);
      }
      
      
    popMatrix();
    
    //update/draw meteors
    for(int i = 0; i < meteors.size(); i++){
      Meteor m = meteors.get(i);
      if(m != selected) m.update();
      
      if(m.hitShip()){
        lives++;
        //GAME OVER
         if(lives >= spaceships.length){
           onScreen = Screen.GAMEOVER;
         }else{
           spaceShip = spaceships[lives];
         }
        if(m == selected){
          selected = null;      
        }
        meteors.remove(i);
      }
    }
    
    
    //draw input circle
    if(selected != null){
      float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
      pushMatrix();
        translate(selected.posx, selected.posy);
        imageMode(CENTER);
        image(stevilcnica, 0, 0);
        
        if(angle > 0 && angle < PI/5){
             //3
             angle = PI/10;
           }else if(angle > PI/5 && angle < 2*PI/5){
             //4
             angle = 3*PI/10;
           }else if(angle > 2*PI/5 && angle < 3*PI/5){
             //5
             angle = 5*PI/10;
           }else if(angle > 3*PI/5 && angle < 4*PI/5){
             //6
             angle = 7*PI/10;
           }else if(angle > 4*PI/5 && angle < 5*PI/5){
             //7
             angle = 9*PI/10;
           }else if(angle > -5*PI/5 && angle < -4*PI/5){
             //8
             angle = -9*PI/10;
           }else if(angle > -4*PI/5 && angle < -3*PI/5){
             //9
             angle = -7*PI/10;
           }else if(angle > -3*PI/5 && angle < -2*PI/5){
             //0
             angle = -5*PI/10;
           }else if(angle > -2*PI/5 && angle < -PI/5){
             //1
             angle = -3*PI/10;
           }else if(angle > -PI/5 && angle < 0){
             //2
             angle = -PI/10;
           }
           
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
      popMatrix();
      
      shipAngle = atan2(selected.posy-height/2, selected.posx-width/2);
    }else{
      shipAngle = atan2(mouseY-height/2, mouseX-width/2);
    }
    if(selected != null)  selected.update();
    
    
    //update/draw bullets
    for(int i = 0; i < bullets.size(); i++){
      Bullet b = bullets.get(i);
      b.update();
    }
  }
}
class Turnado implements Game{
  int prevNumOfDestroied;
  //check meteor constructor for detail
  float aMax, aMin, rMax, rMin;
  
  //meteor speed increse when you destroy one
  float da, dr; 
  
  public Turnado(){
    aMax = 0.008f;
    aMin = 0.002f;
    rMax = 0.5f;
    rMin = 0.7f;
    
    da = 0.001f;
  }
  

 
  public void drawGame(){
    background(background);
    fill(255);
    
    //spawn new meteors
    if(meteors.isEmpty()){
      aMax += da;
      aMin += da;
      meteors.add(new Meteor(mozneStevke, aMin, aMax, rMin, rMax));
      meteors.add(new Meteor(mozneStevke, aMin, aMax, rMin, rMax));
    }
   
    //draw number of destroied meteors
    textSize(32);
    textAlign(LEFT, TOP);
    
    text("Score: " + numOfDestroied, 0, 0);
              
    
    //draw spaceship
    
    pushMatrix();
      translate(width/2, height/2);
      rotate(shipAngle + PI/2);
      imageMode(CENTER);
      image(spaceShip, 0, 0);
       
      if(inputNum1 != null){
          translate(0,-spaceShip.height/2);
          image(inputNum1, 0, -15, 30, 30);
      }
      
      
    popMatrix();
    
    //update/draw meteors
    for(int i = 0; i < meteors.size(); i++){
      Meteor m = meteors.get(i);
      if(m != selected) m.update();
      
      if(m.hitShip()){
        lives++;
        //GAME OVER
         if(lives >= spaceships.length){
           onScreen = Screen.GAMEOVER;
         }else{
           spaceShip = spaceships[lives];
         }
        if(m == selected){
          selected = null;      
        }
        meteors.remove(i);
      }
    }
    
    
    //draw input circle
    if(selected != null){
      float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
      pushMatrix();
        translate(selected.posx, selected.posy);
        imageMode(CENTER);
        image(stevilcnica, 0, 0);
        
        if(angle > 0 && angle < PI/5){
             //3
             angle = PI/10;
           }else if(angle > PI/5 && angle < 2*PI/5){
             //4
             angle = 3*PI/10;
           }else if(angle > 2*PI/5 && angle < 3*PI/5){
             //5
             angle = 5*PI/10;
           }else if(angle > 3*PI/5 && angle < 4*PI/5){
             //6
             angle = 7*PI/10;
           }else if(angle > 4*PI/5 && angle < 5*PI/5){
             //7
             angle = 9*PI/10;
           }else if(angle > -5*PI/5 && angle < -4*PI/5){
             //8
             angle = -9*PI/10;
           }else if(angle > -4*PI/5 && angle < -3*PI/5){
             //9
             angle = -7*PI/10;
           }else if(angle > -3*PI/5 && angle < -2*PI/5){
             //0
             angle = -5*PI/10;
           }else if(angle > -2*PI/5 && angle < -PI/5){
             //1
             angle = -3*PI/10;
           }else if(angle > -PI/5 && angle < 0){
             //2
             angle = -PI/10;
           }
           
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
      popMatrix();
      
      shipAngle = atan2(selected.posy-height/2, selected.posx-width/2);
    }else{
      shipAngle = atan2(mouseY-height/2, mouseX-width/2);
    }
    if(selected != null)  selected.update();
    
    
    //update/draw bullets
    for(int i = 0; i < bullets.size(); i++){
      Bullet b = bullets.get(i);
      b.update();
    }
  }
}
class Twirl implements Game{
  int prevNumOfDestroied;
  //check meteor constructor for detail
  float aMax, aMin, rMax, rMin;
 
  //number of meteors that spawn
  int meteorCount;
  
  public Twirl(){
    aMax = 0.008f;
    aMin = 0.002f;
    rMax = 0.3f;
    rMin = 0.5f;
    
    meteorCount = 0;
  }
  

 
  public void drawGame(){
    background(background);
    fill(255);
    
    //spawn new meteors
    if(meteors.isEmpty()){
      meteorCount++;
      for(int i = 0; i < meteorCount; i++)
        meteors.add(new Meteor(mozneStevke, aMin, aMax, rMin, rMax));
    }
   
    //draw number of destroied meteors
    textSize(32);
    textAlign(LEFT, TOP);
    
    text("Score: " + numOfDestroied, 0, 0);
              
    
    //draw spaceship
    
    pushMatrix();
      translate(width/2, height/2);
      rotate(shipAngle + PI/2);
      imageMode(CENTER);
      image(spaceShip, 0, 0);
       
      if(inputNum1 != null){
          translate(0,-spaceShip.height/2);
          image(inputNum1, 0, -15, 30, 30);
      }
      
      
    popMatrix();
    
    //update/draw meteors
    for(int i = 0; i < meteors.size(); i++){
      Meteor m = meteors.get(i);
      if(m != selected) m.update();
      
      if(m.hitShip()){
        lives++;
        //GAME OVER
         if(lives >= spaceships.length){
           onScreen = Screen.GAMEOVER;
         }else{
           spaceShip = spaceships[lives];
         }
        if(m == selected){
          selected = null;      
        }
        meteors.remove(i);
      }
    }
    
    
    //draw input circle
    if(selected != null){
      float angle = atan2(mouseY-selected.posy, mouseX-selected.posx);
      pushMatrix();
        translate(selected.posx, selected.posy);
        imageMode(CENTER);
        image(stevilcnica, 0, 0);
        
        if(angle > 0 && angle < PI/5){
             //3
             angle = PI/10;
           }else if(angle > PI/5 && angle < 2*PI/5){
             //4
             angle = 3*PI/10;
           }else if(angle > 2*PI/5 && angle < 3*PI/5){
             //5
             angle = 5*PI/10;
           }else if(angle > 3*PI/5 && angle < 4*PI/5){
             //6
             angle = 7*PI/10;
           }else if(angle > 4*PI/5 && angle < 5*PI/5){
             //7
             angle = 9*PI/10;
           }else if(angle > -5*PI/5 && angle < -4*PI/5){
             //8
             angle = -9*PI/10;
           }else if(angle > -4*PI/5 && angle < -3*PI/5){
             //9
             angle = -7*PI/10;
           }else if(angle > -3*PI/5 && angle < -2*PI/5){
             //0
             angle = -5*PI/10;
           }else if(angle > -2*PI/5 && angle < -PI/5){
             //1
             angle = -3*PI/10;
           }else if(angle > -PI/5 && angle < 0){
             //2
             angle = -PI/10;
           }
           
        rotate(angle + PI/2);
        translate(0,-100);
        image(select,0,0);
      popMatrix();
      
      shipAngle = atan2(selected.posy-height/2, selected.posx-width/2);
    }else{
      shipAngle = atan2(mouseY-height/2, mouseX-width/2);
    }
    if(selected != null)  selected.update();
    
    
    //update/draw bullets
    for(int i = 0; i < bullets.size(); i++){
      Bullet b = bullets.get(i);
      b.update();
    }
  }
}
  public void settings() {  size(1600,900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Math_Space_1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
